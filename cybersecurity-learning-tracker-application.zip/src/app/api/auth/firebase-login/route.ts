import { randomBytes } from "crypto";
import { NextResponse, type NextRequest } from "next/server";
import {
  attachSessionCookie,
  createAuthenticatedSession,
  getHashedClientIpKey,
  verifySameOriginRequest,
} from "@/lib/auth/session";
import { getAdminAuth, isFirebaseAdminConfigured } from "@/lib/firebase/admin";
import { getRepository, syncRoadmapForUser } from "@/lib/storage";
import { firebaseLoginSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    if (!verifySameOriginRequest(request)) {
      return NextResponse.json(
        { error: "Cross-origin sign-in request denied." },
        { status: 403, headers: { "Cache-Control": "no-store" } }
      );
    }

    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json(
        { error: "Firebase Admin SDK is not configured on the server." },
        { status: 400, headers: { "Cache-Control": "no-store" } }
      );
    }

    const repo = getRepository();
    const rateKey = getHashedClientIpKey(request, "firebase_login");
    const rate = await repo.checkAndIncrementRateLimit(rateKey, 8, 15 * 60 * 1000);
    if (!rate.allowed) {
      return NextResponse.json(
        { error: "Too many sign-in attempts. Please wait and try again." },
        {
          status: 429,
          headers: {
            "Cache-Control": "no-store",
            "Retry-After": String(rate.retryAfterSeconds),
          },
        }
      );
    }

    const body = await request.json().catch(() => null);
    const parsed = firebaseLoginSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid Firebase authentication token." },
        { status: 400, headers: { "Cache-Control": "no-store" } }
      );
    }

    const decoded = await getAdminAuth().verifyIdToken(parsed.data.idToken, true);
    const uid = decoded.uid;
    const email = (decoded.email || "").toLowerCase();

    const allowedUid = process.env.FIREBASE_ALLOWED_UID?.trim();
    const allowedEmail = process.env.FIREBASE_ALLOWED_EMAIL?.trim().toLowerCase();

    if (allowedUid && uid !== allowedUid) {
      return NextResponse.json(
        { error: "This account is not authorized to access this tracker." },
        { status: 403, headers: { "Cache-Control": "no-store" } }
      );
    }
    if (allowedEmail && email !== allowedEmail) {
      return NextResponse.json(
        { error: "This email address is not authorized to access this tracker." },
        { status: 403, headers: { "Cache-Control": "no-store" } }
      );
    }

    // Single-user lock when public registration is not explicitly enabled
    const allowPublic = process.env.ALLOW_PUBLIC_REGISTRATION === "true";
    const vault = await repo.getOwnerVault();
    if (!allowPublic && !allowedUid && !allowedEmail) {
      if (!vault || vault.ownerUid === "owner-primary") {
        const nowIso = new Date().toISOString();
        await repo.saveOwnerVault({
          ownerUid: uid,
          ownerEmail: email || null,
          passwordHash: vault?.passwordHash ?? null,
          sessionSecret: vault?.sessionSecret ?? randomBytes(32).toString("hex"),
          createdAt: vault?.createdAt ?? nowIso,
          updatedAt: nowIso,
        });
      } else if (vault.ownerUid !== uid) {
        return NextResponse.json(
          {
            error:
              "Single-user protection active: only the registered owner account is permitted.",
          },
          { status: 403, headers: { "Cache-Control": "no-store" } }
        );
      }
    }

    await repo.resetRateLimit(rateKey);
    await syncRoadmapForUser(uid);

    const { cookieValue, session } = await createAuthenticatedSession(
      uid,
      "firebase"
    );

    const response = NextResponse.json(
      {
        authenticated: true,
        userId: session.userId,
        csrfToken: session.csrfToken,
      },
      { headers: { "Cache-Control": "private, no-store" } }
    );
    attachSessionCookie(response, cookieValue);
    return response;
  } catch {
    return NextResponse.json(
      { error: "Firebase token verification failed." },
      { status: 401, headers: { "Cache-Control": "no-store" } }
    );
  }
}

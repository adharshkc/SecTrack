import { getApps, initializeApp, type FirebaseApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";

export function getFirebaseClientConfig() {
  return {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "",
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "",
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "",
    appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "",
  };
}

export function isFirebaseClientConfigured(): boolean {
  const cfg = getFirebaseClientConfig();
  return Boolean(cfg.apiKey && cfg.authDomain && cfg.projectId);
}

export function getFirebaseClientApp(): FirebaseApp {
  const existing = getApps();
  if (existing.length > 0) return existing[0];
  const cfg = getFirebaseClientConfig();
  if (!cfg.apiKey || !cfg.projectId) {
    throw new Error("Firebase client configuration is missing.");
  }
  return initializeApp(cfg);
}

export function getFirebaseClientAuth(): Auth {
  return getAuth(getFirebaseClientApp());
}

import { randomBytes } from "crypto";
import { NextResponse, type NextRequest } from "next/server";
import { hashPasswordScrypt } from "@/lib/auth/password";
import {
  attachSessionCookie,
  createAuthenticatedSession,
  getAuthSystemStatus,
  getHashedClientIpKey,
  SINGLE_OWNER_DEFAULT_UID,
  verifySameOriginRequest,
} from "@/lib/auth/session";
import { getRepository, syncRoadmapForUser } from "@/lib/storage";
import { vaultSetupSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    if (!verifySameOriginRequest(request)) {
      return NextResponse.json(
        { error: "Cross-origin setup request denied." },
        { status: 403, headers: { "Cache-Control": "no-store" } }
      );
    }

    const status = await getAuthSystemStatus();
    if (status.mode !== "vault_master_password" || status.vaultInitialized) {
      return NextResponse.json(
        {
          error:
            "Single-user owner vault is already initialized. Public registration is disabled.",
        },
        { status: 403, headers: { "Cache-Control": "no-store" } }
      );
    }

    const repo = getRepository();
    const rateKey = getHashedClientIpKey(request, "setup");
    const rate = await repo.checkAndIncrementRateLimit(rateKey, 5, 15 * 60 * 1000);
    if (!rate.allowed) {
      return NextResponse.json(
        { error: "Too many attempts. Please wait before trying again." },
        {
          status: 429,
          headers: {
            "Cache-Control": "no-store",
            "Retry-After": String(rate.retryAfterSeconds),
          },
        }
      );
    }

    const body = await request.json().catch(() => null);
    const parsed = vaultSetupSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message || "Invalid password input." },
        { status: 400, headers: { "Cache-Control": "no-store" } }
      );
    }

    const existingVault = await repo.getOwnerVault();
    if (existingVault?.passwordHash) {
      return NextResponse.json(
        { error: "Owner vault is already locked." },
        { status: 403, headers: { "Cache-Control": "no-store" } }
      );
    }

    const passwordHash = await hashPasswordScrypt(parsed.data.password);
    const nowIso = new Date().toISOString();
    const sessionSecret =
      existingVault?.sessionSecret || randomBytes(32).toString("hex");

    await repo.saveOwnerVault({
      ownerUid: SINGLE_OWNER_DEFAULT_UID,
      ownerEmail: null,
      passwordHash,
      sessionSecret,
      createdAt: existingVault?.createdAt || nowIso,
      updatedAt: nowIso,
    });

    await repo.resetRateLimit(rateKey);
    await syncRoadmapForUser(SINGLE_OWNER_DEFAULT_UID);

    const { cookieValue, session } = await createAuthenticatedSession(
      SINGLE_OWNER_DEFAULT_UID,
      "vault_password"
    );

    const response = NextResponse.json(
      {
        authenticated: true,
        userId: session.userId,
        csrfToken: session.csrfToken,
      },
      { status: 201, headers: { "Cache-Control": "private, no-store" } }
    );
    attachSessionCookie(response, cookieValue);
    return response;
  } catch {
    return NextResponse.json(
      { error: "Failed to initialize owner vault." },
      { status: 500, headers: { "Cache-Control": "no-store" } }
    );
  }
}
